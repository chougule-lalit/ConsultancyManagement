export interface IUser {
  id: number;
  isSuccess: boolean;
  role: number
}